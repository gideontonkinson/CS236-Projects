//
// Created by Gideon Tonkinson on 9/28/21.
//

#ifndef PROJECT_2_PARAMETER_H
#define PROJECT_2_PARAMETER_H
#include <string>

class Parameter {
private:
    std::string p;
public:
    Parameter(std::string p);
    std::string toString();
};


#endif //PROJECT_2_PARAMETER_H
