//
// Created by Gideon Tonkinson on 9/9/21.
//

#include "EOFAutomaton.h"

void EOFAutomaton::S0(const std::string& input){
}